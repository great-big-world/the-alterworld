package dev.creoii.greatbigworld.thealterworld.mixin.world;

import com.mojang.datafixers.util.Pair;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Consumer;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_5321;
import net.minecraft.class_6544;
import net.minecraft.class_6554;

@Mixin(class_6554.class)
public abstract class VanillaBiomeParametersMixin {
    @Mutable @Shadow @Final private class_5321<class_1959>[][] commonBiomes;
    @Mutable @Shadow @Final private class_5321<class_1959>[][] uncommonBiomes;
    @Mutable @Shadow @Final private class_5321<class_1959>[][] nearMountainBiomes;
    @Mutable @Shadow @Final private class_5321<class_1959>[][] specialNearMountainBiomes;
    @Mutable @Shadow @Final private class_5321<class_1959>[][] windsweptBiomes;
    @Shadow @Final private class_6544.class_6546[] temperatureParameters;
    @Shadow @Final private class_6544.class_6546 defaultParameter;
    @Shadow @Final private class_6544.class_6546 nearInlandContinentalness;
    @Shadow @Final private class_6544.class_6546 farInlandContinentalness;
    @Shadow @Final private class_6544.class_6546[] erosionParameters;
    @Shadow protected abstract void writeBiomeParameters(Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome);

    @SuppressWarnings("unchecked")
    @Inject(method = "<init>", at = @At("TAIL"))
    private void gbw$replaceOldGrowthBirchForest(CallbackInfo ci) {
        commonBiomes = new class_5321[][]{{class_1972.field_35117, class_1972.field_35117, class_1972.field_35117, class_1972.field_9454, class_1972.field_9420}, {class_1972.field_9451, class_1972.field_9451, class_1972.field_9409, class_1972.field_9420, class_1972.field_9420}, {class_1972.field_9451, class_1972.field_9451, class_1972.field_9409, class_1972.field_9412, class_1972.field_9412}, {class_1972.field_9449, class_1972.field_9449, class_1972.field_9409, class_1972.field_9417, class_1972.field_9417}, {class_1972.field_9424, class_1972.field_9424, class_1972.field_9424, class_1972.field_9424, class_1972.field_9424}};
        uncommonBiomes = new class_5321[][]{{class_1972.field_9453, null, class_1972.field_9454, null, null}, {null, null, null, null, class_1972.field_9420}, {class_1972.field_9451, null, null, class_1972.field_9412, null}, {null, null, class_1972.field_9451, class_1972.field_9417, class_1972.field_9417}, {null, null, null, null, null}};
        nearMountainBiomes = new class_5321[][]{{class_1972.field_35117, class_1972.field_35117, class_1972.field_35117, class_1972.field_9454, class_1972.field_9454}, {class_1972.field_34470, class_1972.field_34470, class_1972.field_9409, class_1972.field_9420, class_1972.field_9420}, {class_1972.field_34470, class_1972.field_34470, class_1972.field_34470, class_1972.field_34470, class_1972.field_9409}, {class_1972.field_9449, class_1972.field_9449, class_1972.field_9409, class_1972.field_9409, class_1972.field_9417}, {class_1972.field_9415, class_1972.field_9415, class_1972.field_9415, class_1972.field_35110, class_1972.field_35110}};
        specialNearMountainBiomes = new class_5321[][]{{class_1972.field_9453, null, null, null, null}, {null, null, class_1972.field_34470, class_1972.field_34470, class_1972.field_9420}, {class_1972.field_42720, class_1972.field_42720, class_1972.field_9409, class_1972.field_9412, null}, {null, null, null, null, null}, {class_1972.field_9443, class_1972.field_9443, null, null, null}};
        windsweptBiomes = new class_5321[][]{{class_1972.field_35111, class_1972.field_35111, class_1972.field_35116, class_1972.field_35120, class_1972.field_35120}, {class_1972.field_35111, class_1972.field_35111, class_1972.field_35116, class_1972.field_35120, class_1972.field_35120}, {class_1972.field_35116, class_1972.field_35116, class_1972.field_35116, class_1972.field_35120, class_1972.field_35120}, {null, null, null, null, null}, {null, null, null, null, null}};
    }

    @Redirect(method = "writeLowBiomes", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/source/util/VanillaBiomeParameters;writeBiomeParameters(Ljava/util/function/Consumer;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;FLnet/minecraft/registry/RegistryKey;)V", ordinal = 2))
    private void gbw$removeMangroveSwampLow(class_6554 instance, Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome) {
        writeBiomeParameters(parameters, class_6544.class_6546.method_38123(temperatureParameters[3], temperatureParameters[4]), defaultParameter, class_6544.class_6546.method_38123(nearInlandContinentalness, farInlandContinentalness), erosionParameters[6], weirdness, 0f, class_1972.field_9471);
    }

    @Redirect(method = "writeMidBiomes", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/source/util/VanillaBiomeParameters;writeBiomeParameters(Ljava/util/function/Consumer;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;FLnet/minecraft/registry/RegistryKey;)V", ordinal = 2))
    private void gbw$removeMangroveSwampMid(class_6554 instance, Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome) {
        writeBiomeParameters(parameters, class_6544.class_6546.method_38123(temperatureParameters[3], temperatureParameters[4]), defaultParameter, class_6544.class_6546.method_38123(nearInlandContinentalness, farInlandContinentalness), erosionParameters[6], weirdness, 0f, class_1972.field_9471);
    }

    @Redirect(method = "writeValleyBiomes", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/source/util/VanillaBiomeParameters;writeBiomeParameters(Ljava/util/function/Consumer;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;FLnet/minecraft/registry/RegistryKey;)V", ordinal = 9))
    private void gbw$removeMangroveSwampValley(class_6554 instance, Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome) {
        writeBiomeParameters(parameters, class_6544.class_6546.method_38123(temperatureParameters[3], temperatureParameters[4]), defaultParameter, class_6544.class_6546.method_38123(nearInlandContinentalness, farInlandContinentalness), erosionParameters[6], weirdness, 0f, class_1972.field_9471);
    }

    @Inject(method = "getBiomeOrWindsweptSavanna", at = @At(value = "RETURN", ordinal = 0), cancellable = true)
    private void gbw$removeWindsweptSavanna(int temperature, int humidity, class_6544.class_6546 weirdness, class_5321<class_1959> biomeKey, CallbackInfoReturnable<class_5321<class_1959>> cir) {
        cir.setReturnValue(class_1972.field_9449);
    }
}
